## MailAutoSent


## useage

```
from MailAutoSent impirt Mail
Mail.Mail("host","sender","API_token").sendmail("receiver","Titie","Message")
```